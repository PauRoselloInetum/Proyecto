import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Cliente } from './models/cliente';
import { ClienteService } from './services/cliente.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ClientesCRUD3';
  clientes: Cliente[] = [];

  constructor(private ClienteService: ClienteService){}

  ngOnInit() : void {
    this.ClienteService.getClientes().subscribe((result: Cliente[]) => (this.clientes = result));
  }
}
