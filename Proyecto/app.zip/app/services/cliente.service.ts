import { Injectable } from '@angular/core';
import { Cliente } from '../models/cliente';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  
  private url = "Cliente";
  
  constructor(private httpClient: HttpClient) { }

  public getClientes() : Observable<Cliente[]> {
    return this.httpClient.get<Cliente[]>(`${environment.apiUrl}/${this.url}`);
  }
}
