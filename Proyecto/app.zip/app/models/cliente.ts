export class Cliente {
    id?: number;
    nombre = "";
    apellido = "";
    dept = "";
}