// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

export const environment = {
    
    // SI ALGO PETA, ESTO POR LO MENOS SÍ FUNCIONA (correr la api desde visual 22 previamente)
    production: false,
   apiUrl: "https://localhost:7152/api",
   
   
    /*
    // API DE FIREBASE 
    //      |
    //      v

    // TODO: Add SDKs for Firebase products that you want to use
    // https://firebase.google.com/docs/web/setup#available-libraries

    // Your web app's Firebase configuration
    // For Firebase JS SDK v7.20.0 and later, measurementId is optional
    production: false,
    firebaseConfig: {
      apiKey: "AIzaSyBeG4Ba4o-FFXhN3l4FNGUuCJM7onjmezc",
      authDomain: "test-2f0bb.firebaseapp.com",
      projectId: "test-2f0bb",
      storageBucket: "test-2f0bb.appspot.com",
      messagingSenderId: "216996301659",
      appId: "1:216996301659:web:a447e96ca94c927a29287e"
    }


    */
};

