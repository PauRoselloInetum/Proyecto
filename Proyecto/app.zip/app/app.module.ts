import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from "./app.component";
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { ClienteService } from "./services/cliente.service";
import { AngularFireModule } from '@angular/fire/compat';
import { environment } from "./environments/environment";

@NgModule({
    declarations: [ AppComponent], //EN EL TUTORIAL ESTÁ ASÍ
   // declarations : [],
    imports: [ BrowserModule, AppComponent, HttpClientModule, HttpClient /*, AngularFireModule.initializeApp(environment.firebaseConfig) */], // EN EL TUTORIAL AppComponent SE DECLARA, NO SE IMPORTA
   // providers: [ClienteService],
    bootstrap: [AppComponent]    
})
export class AppModule {}